const hiddenSpace = document.getElementById("hidden-space");
const unlockBtn = document.getElementById("unlock-btn");

async function unlockWithFingerprint() {
  try {
    const publicKey = {
      challenge: new Uint8Array([0x8C,0x1A,0x2B,0x3C]),
      allowCredentials: [],
      timeout: 60000,
      userVerification: "preferred"
    };

    const credential = await navigator.credentials.get({ publicKey });

    if (credential) {
      hiddenSpace.classList.add("unlocked");
      unlockBtn.style.display = "none";
      alert("Espacio oculto desbloqueado ✅");
    }
  } catch (err) {
    alert("Autenticación fallida ❌");
    console.error(err);
  }
}

unlockBtn.addEventListener("click", unlockWithFingerprint);

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("sw.js")
      .then(() => console.log("Service Worker registrado ✅"))
      .catch(err => console.log("Error SW:", err));
  });
}